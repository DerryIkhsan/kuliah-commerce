<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <h2>Show Produk</h2>
            <br>
            
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-group">
                    <label for="">Nama Produk</label>
                    <input type="text" name="name" id="" class="form-control" placeholder="Nama Produk" value="<?php echo e($p->name); ?>" readonly>
                </div>
                <div class="form-group">
                    <label for="">Harga</label>
                    <input type="number" name="price" id="" class="form-control" placeholder="Harga" readonly>
                </div>
                <div class="form-group">
                    <label for="">Deskripsi</label>
                    <textarea name="description" id="" rows="3" class="form-control" placeholder="Deskripsi" readonly><?php echo e($p->description); ?></textarea>
                </div>
                <div class="form-group">
                    <label for="">Dibuat Tanggal</label>
                    <input type="text" name="" id="" class="form-control" readonly value="<?php echo e(date('d M Y', strtotime($p->created_at))); ?>">
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-success">Kembali</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>