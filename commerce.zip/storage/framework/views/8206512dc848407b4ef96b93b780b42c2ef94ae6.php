<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col">
            <h2>Ubah Produk</h2>
            <br>
            <?php if(count($errors)): ?>
            <div class="form-group">
                <div class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>
        
            <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <form action="/admin/products/update" method="post">
                <?php echo e(csrf_field()); ?>


                <input type="hidden" name="id" value="<?php echo e($p->id); ?>">
                <div class="form-group">
                    <label for="">Nama Produk</label>
                    <input type="text" name="name" id="" class="form-control" placeholder="Nama Produk" value="<?php echo e($p->name); ?>">
                </div>
                <div class="form-group">
                    <label for="">Harga</label>
                    <input type="number" name="price" id="" class="form-control" placeholder="Harga" value="<?php echo e($p->price); ?>">
                </div>
                <div class="form-group">
                    <label for="">Deskripsi</label>
                    <textarea name="description" id="" rows="3" class="form-control tinymce" placeholder="Deskripsi"><?php echo e($p->description); ?></textarea>
                </div>
                <!-- <div class="form-group">
                    <label for="">Image</label>
                    <input type="file" name="image_url" id="" class="form-control">
                </div> -->

                <a href="<?php echo e(route('admin.products.index')); ?>" class="btn btn-sm btn-success">Kembali</a>
                <button class="btn btn-sm btn-primary float-right">Submit</button>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>